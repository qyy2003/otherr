#include <bits/stdc++.h>
using namespace std;

int main() {
    srand(time(NULL));
    cout << rand() % 100 << " " << rand() % 100 << endl;
    return 0;
}
